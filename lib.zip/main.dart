import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'login_screen.dart';
import 'home_screen.dart';

// GLOBAL theme notifier
final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.system);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url:
        'https://your-project-id.supabase.co', // ⬅️ Replace with your actual URL
    anonKey: 'your-anon-key', // ⬅️ Replace with your actual anon key
  );
  runApp(const CrystalApp());
}

class CrystalApp extends StatefulWidget {
  const CrystalApp({super.key});

  @override
  State<CrystalApp> createState() => _CrystalAppState();
}

class _CrystalAppState extends State<CrystalApp> {
  String? _username;
  bool _showSplash = true;

  @override
  void initState() {
    super.initState();
    _loadUserThemePreference();
  }

  Future<void> _loadUserThemePreference() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;

    final data = await Supabase.instance.client
        .from('users')
        .select('prefersDarkMode')
        .eq('id', user.id)
        .maybeSingle();

    final prefersDark = data?['prefersDarkMode'] ?? false;
    themeNotifier.value = prefersDark ? ThemeMode.dark : ThemeMode.light;
  }

  void _handleLogin(String username) {
    setState(() {
      _username = username;
    });
  }

  void _handleSplashFinished() {
    setState(() {
      _showSplash = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (context, mode, _) {
        return MaterialApp(
          title: 'CrystalApp',
          themeMode: mode,
          theme: ThemeData(
            primarySwatch: Colors.pink,
            scaffoldBackgroundColor: const Color(0xFFFED8E6), // Pastel mode 💗
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.pinkAccent,
              foregroundColor: Colors.white,
            ),
          ),
          darkTheme: ThemeData.dark().copyWith(
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.black87,
              foregroundColor: Colors.white,
            ),
          ),
          home: _showSplash
              ? SplashScreen(onFinished: _handleSplashFinished)
              : (_username == null
                  ? LoginScreen(onLogin: _handleLogin)
                  : HomeScreen(currentUserId: _username!)),
        );
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  final VoidCallback onFinished;

  const SplashScreen({super.key, required this.onFinished});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scaleAnimation;
  late final Animation<double> _fadeOutAnimation;

  final int sparkleCount = 15;
  final List<_Sparkle> sparkles = [];

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );

    _scaleAnimation = TweenSequence([
      TweenSequenceItem(
        tween: Tween(begin: 0.5, end: 1.2)
            .chain(CurveTween(curve: Curves.elasticOut)),
        weight: 70,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.2, end: 1.0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 30,
      ),
    ]).animate(_controller);

    _fadeOutAnimation = Tween<double>(begin: 1, end: 0).animate(
      CurvedAnimation(parent: _controller, curve: const Interval(0.7, 1)),
    );

    _controller.forward();

    for (int i = 0; i < sparkleCount; i++) {
      sparkles.add(_Sparkle(
        vsync: this,
        delay: i * 150,
        left: 50 + (100 * (i / sparkleCount)),
        top: 50 + (100 * ((sparkleCount - i) / sparkleCount)),
        size: (5 + (i % 3) * 3).toDouble(),
      ));
    }

    Future.delayed(const Duration(milliseconds: 2500), widget.onFinished);
  }

  @override
  void dispose() {
    _controller.dispose();
    for (var sparkle in sparkles) {
      sparkle.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeOutAnimation,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Scaffold(
          backgroundColor: Colors.pink.shade100,
          body: Center(
            child: Stack(
              alignment: Alignment.center,
              children: [
                const Text(
                  "💖",
                  style: TextStyle(
                    fontSize: 120,
                    shadows: [
                      Shadow(
                        color: Colors.pinkAccent,
                        blurRadius: 30,
                      ),
                    ],
                  ),
                ),
                ...sparkles.map((sparkle) => sparkle.build(context)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Sparkle {
  final int delay;
  final double left;
  final double top;
  final double size;
  final TickerProvider vsync;
  late final AnimationController controller;
  late final Animation<double> animation;

  _Sparkle({
    required this.vsync,
    required this.delay,
    required this.left,
    required this.top,
    required this.size,
  }) {
    controller = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: vsync,
    );

    animation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 1.0), weight: 50),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.0), weight: 50),
    ]).animate(CurvedAnimation(parent: controller, curve: Curves.easeInOut));

    Future.delayed(Duration(milliseconds: delay), () {
      controller.repeat();
    });
  }

  Widget build(BuildContext context) {
    return Positioned(
      left: left,
      top: top,
      child: FadeTransition(
        opacity: animation,
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            color: Colors.white.withAlpha((0.8 * 255).round()),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withAlpha((0.9 * 255).round()),
                blurRadius: 6,
                spreadRadius: 1,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void dispose() {
    controller.dispose();
  }
}
