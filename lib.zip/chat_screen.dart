import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:sensors_plus/sensors_plus.dart';

import 'widgets/message_bubble.dart';

class ChatScreen extends StatefulWidget {
  final String currentUser;
  final String otherUser;
  final String chatId;

  const ChatScreen({
    required this.currentUser,
    required this.otherUser,
    required this.chatId,
    super.key,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _scroll = ScrollController();
  final supabase = Supabase.instance.client;

  Timer? _typingTimer;
  StreamSubscription? _accelerometerSub;

  String? myAvatarUrl;
  String? otherAvatarUrl;
  String? _chatBackgroundUrl;
  String? _globalChatBackgroundUrl;
  String _customSleepyReply =
      "💤 I’m in Sleepy Mode... I’ll get right back to you!";

  bool _butterflyVisible = false;
  bool _isSecretMode = false;
  DateTime? _stillSince;

  List<Map<String, dynamic>> messages = [];

  @override
  void initState() {
    super.initState();
    _loadUserAvatars();
    _loadChatBackground();
    _loadGlobalChatBackground();
    _loadOtherUserSleepyReply();
    _loadMessages();
    _listenToButterflyMode();
  }

  @override
  void dispose() {
    _controller.dispose();
    _scroll.dispose();
    _typingTimer?.cancel();
    _accelerometerSub?.cancel();
    super.dispose();
  }

  void _listenToButterflyMode() {
    _accelerometerSub = accelerometerEvents.listen((event) {
      final double magnitude =
          sqrt(event.x * event.x + event.y * event.y + event.z * event.z);
      final bool isStill = (magnitude - 9.8).abs() < 0.05;

      if (isStill) {
        _stillSince ??= DateTime.now();
        if (!_butterflyVisible &&
            DateTime.now().difference(_stillSince!) >
                const Duration(seconds: 5)) {
          setState(() => _butterflyVisible = true);
        }
      } else {
        _stillSince = null;
        if (_butterflyVisible) setState(() => _butterflyVisible = false);
      }
    });
  }

  Future<void> _loadUserAvatars() async {
    final current = await supabase
        .from('users')
        .select('avatarUrl')
        .eq('id', widget.currentUser)
        .maybeSingle();
    final other = await supabase
        .from('users')
        .select('avatarUrl')
        .eq('id', widget.otherUser)
        .maybeSingle();

    setState(() {
      myAvatarUrl = current?['avatarUrl'];
      otherAvatarUrl = other?['avatarUrl'];
    });
  }

  Future<void> _loadChatBackground() async {
    final doc = await supabase
        .from('chats')
        .select('backgroundUrl')
        .eq('id', widget.chatId)
        .maybeSingle();
    setState(() => _chatBackgroundUrl = doc?['backgroundUrl']);
  }

  Future<void> _loadGlobalChatBackground() async {
    final doc = await supabase
        .from('users')
        .select('globalChatBackgroundUrl')
        .eq('id', widget.currentUser)
        .maybeSingle();
    setState(() => _globalChatBackgroundUrl = doc?['globalChatBackgroundUrl']);
  }

  Future<void> _loadOtherUserSleepyReply() async {
    final doc = await supabase
        .from('users')
        .select('sleepyAutoReplyText')
        .eq('id', widget.otherUser)
        .maybeSingle();
    if (doc?['sleepyAutoReplyText'] != null) {
      setState(() => _customSleepyReply = doc!['sleepyAutoReplyText']);
    }
  }

  Future<void> _maybeSendSleepyAutoReply() async {
    final doc = await supabase
        .from('users')
        .select('isSleepyModeOn, sleepyAutoReply, sleepyAutoReplyText')
        .eq('id', widget.otherUser)
        .maybeSingle();

    if (doc != null &&
        doc['isSleepyModeOn'] == true &&
        doc['sleepyAutoReply'] == true) {
      final reply = doc['sleepyAutoReplyText'] ?? _customSleepyReply;
      await supabase.from('messages').insert({
        'chat_id': widget.chatId,
        'sender_id': widget.otherUser,
        'text': reply,
        'timestamp': DateTime.now().toIso8601String(),
        'status': 'sent',
      });
    }
  }

  Future<void> _sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    await supabase.from('messages').insert({
      'chat_id': widget.chatId,
      'sender_id': widget.currentUser,
      'text': text.trim(),
      'timestamp': DateTime.now().toIso8601String(),
      'status': 'sent',
      'isSecret': _isSecretMode,
    });

    await _maybeSendSleepyAutoReply();

    _controller.clear();
    setState(() => _isSecretMode = false);

    _scroll.animateTo(
      _scroll.position.maxScrollExtent + 80,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );

    _loadMessages();
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image == null) return;

    final file = File(image.path);
    final fileName = path.basename(image.path);
    final storageRef = 'chats/${widget.chatId}/$fileName';

    await supabase.storage
        .from('chat_images')
        .uploadBinary(storageRef, await file.readAsBytes());

    final imageUrl =
        supabase.storage.from('chat_images').getPublicUrl(storageRef);

    await supabase.from('messages').insert({
      'chat_id': widget.chatId,
      'sender_id': widget.currentUser,
      'image': imageUrl,
      'timestamp': DateTime.now().toIso8601String(),
      'status': 'sent',
    });

    _scroll.jumpTo(_scroll.position.maxScrollExtent + 200);

    _loadMessages();
  }

  Future<void> _sendButterflyMessage() async {
    setState(() => _butterflyVisible = false);

    await supabase.from('messages').insert({
      'chat_id': widget.chatId,
      'sender_id': widget.currentUser,
      'text': '🦋 Peaceful Vibe',
      'timestamp': DateTime.now().toIso8601String(),
      'status': 'sent',
    });

    _scroll.animateTo(
      _scroll.position.maxScrollExtent + 80,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );

    _loadMessages();
  }

  Future<void> _loadMessages() async {
    final res = await supabase
        .from('messages')
        .select()
        .eq('chat_id', widget.chatId)
        .order('timestamp', ascending: true);

    setState(() {
      messages = res;
    });
  }

  Future<void> _toggleReaction(String messageId, String emoji) async {
    final msg = await supabase
        .from('messages')
        .select('reactions')
        .eq('id', messageId)
        .single();

    final current = Map<String, List<String>>.from(msg['reactions'] ?? {});
    final users = current[emoji] ?? [];

    if (users.contains(widget.currentUser)) {
      users.remove(widget.currentUser);
      if (users.isEmpty) {
        current.remove(emoji);
      } else {
        current[emoji] = users;
      }
    } else {
      users.add(widget.currentUser);
      current[emoji] = users;
    }

    await supabase
        .from('messages')
        .update({'reactions': current}).eq('id', messageId);

    _loadMessages();
  }

  void _showEmojiPicker(String messageId) {
    showModalBottomSheet(
      context: context,
      builder: (context) => EmojiPicker(
        onEmojiSelected: (category, emoji) {
          Navigator.pop(context);
          _toggleReaction(messageId, emoji.emoji);
        },
        config: const Config(
          columns: 7,
          emojiSizeMax: 32,
          bgColor: Color(0xFFFED8E6),
          indicatorColor: Colors.pinkAccent,
        ),
      ),
    );
  }

  void _showEffectPicker(String messageId) async {
    final effect = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text("Pick a message effect"),
        children: [
          SimpleDialogOption(
              child: const Text("🎉 Bounce"),
              onPressed: () => Navigator.pop(context, "bounce")),
          SimpleDialogOption(
              child: const Text("💓 Pulse"),
              onPressed: () => Navigator.pop(context, "pulse")),
          SimpleDialogOption(
              child: const Text("🕊 Float"),
              onPressed: () => Navigator.pop(context, "float")),
          SimpleDialogOption(
              child: const Text("❌ Remove effect"),
              onPressed: () => Navigator.pop(context, null)),
        ],
      ),
    );

    await supabase
        .from('messages')
        .update({'effect': effect}).eq('id', messageId);

    _loadMessages();
  }

  Widget _buildMessage(Map<String, dynamic> data) {
    final isMe = data['sender_id'] == widget.currentUser;
    final reactions = Map<String, List<String>>.from(data['reactions'] ?? {});

    return MessageBubble(
      text: data['text'] ?? '',
      imageUrl: data['image'],
      isMe: isMe,
      timestamp: DateTime.tryParse(data['timestamp'] ?? ''),
      status: data['status'] ?? 'sent',
      avatarUrl: isMe ? myAvatarUrl : otherAvatarUrl,
      reactions: reactions,
      effect: data['effect'],
      isSecret: data['isSecret'] == true,
      onReactTap: (emoji) => _toggleReaction(data['id'], emoji),
      onLongPress: () =>
          isMe ? _showEffectPicker(data['id']) : _showEmojiPicker(data['id']),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Chat with ${widget.otherUser}"),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: _chatBackgroundUrl != null
                  ? DecorationImage(
                      image: NetworkImage(_chatBackgroundUrl!),
                      fit: BoxFit.cover)
                  : _globalChatBackgroundUrl != null
                      ? DecorationImage(
                          image: NetworkImage(_globalChatBackgroundUrl!),
                          fit: BoxFit.cover)
                      : null,
            ),
            child: Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    controller: _scroll,
                    itemCount: messages.length,
                    itemBuilder: (context, i) => _buildMessage(messages[i]),
                  ),
                ),
                Container(
                  color: const Color(0xFFFDE4EC),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      IconButton(
                          icon:
                              const Icon(Icons.image, color: Colors.pinkAccent),
                          onPressed: _sendImage),
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          decoration: InputDecoration(
                            hintText: _isSecretMode
                                ? "Type secret message... 🔒"
                                : "Type your message...",
                            border: InputBorder.none,
                          ),
                        ),
                      ),
                      IconButton(
                        icon: Icon(
                          _isSecretMode ? Icons.lock : Icons.lock_open,
                          color:
                              _isSecretMode ? Colors.pinkAccent : Colors.grey,
                        ),
                        onPressed: () =>
                            setState(() => _isSecretMode = !_isSecretMode),
                      ),
                      IconButton(
                        icon: const Icon(Icons.send, color: Colors.pinkAccent),
                        onPressed: () => _sendMessage(_controller.text),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (_butterflyVisible)
            Positioned(
              bottom: 100,
              right: 40,
              child: GestureDetector(
                onTap: _sendButterflyMessage,
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.pinkAccent.withOpacity(0.4),
                        blurRadius: 10,
                        spreadRadius: 3,
                      ),
                    ],
                  ),
                  child: const Text("🦋", style: TextStyle(fontSize: 32)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
