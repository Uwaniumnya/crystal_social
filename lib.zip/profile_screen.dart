import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'edit_profile_screen.dart';

class ProfileScreen extends StatefulWidget {
  final String userId;
  final String username;
  final String? avatarUrl;

  const ProfileScreen({
    super.key,
    required this.userId,
    required this.username,
    this.avatarUrl,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String bio = '';
  String email = '';
  int chatCount = 0;
  int messageCount = 0;

  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _loadUserInfo();
    _loadUserStats();
  }

  Future<void> _loadUserInfo() async {
    final data = await supabase
        .from('users')
        .select('bio, email')
        .eq('id', widget.userId)
        .maybeSingle();

    if (!mounted || data == null) return;

    setState(() {
      bio = data['bio'] ?? 'No bio yet. Add one!';
      email = data['email'] ?? 'No email provided';
    });
  }

  Future<void> _loadUserStats() async {
    final chats = await supabase
        .from('chats')
        .select('id')
        .contains('participants', [widget.userId]);

    // 🟡 Placeholder: message counting depends on your schema
    int totalMessages = 0;

    // TODO: Count messages per chat using a flat messages table if available
    // Example: await supabase.from('messages').select().eq('sender_id', widget.userId)

    if (!mounted) return;

    setState(() {
      chatCount = chats.length;
      messageCount = totalMessages;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.username),
        backgroundColor: Colors.pinkAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            tooltip: 'Edit Profile',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EditProfileScreen(
                    userId: widget.userId,
                    currentUsername: widget.username,
                    currentBio: bio,
                    currentAvatarUrl: widget.avatarUrl ?? '',
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            CircleAvatar(
              radius: 50,
              backgroundImage: widget.avatarUrl != null
                  ? NetworkImage(widget.avatarUrl!)
                  : const AssetImage('assets/default_avatar.png')
                      as ImageProvider,
            ),
            const SizedBox(height: 16),
            Text(
              widget.username,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              bio.isNotEmpty ? bio : 'Loading bio...',
              style: const TextStyle(
                  fontStyle: FontStyle.italic, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.email, color: Colors.pinkAccent),
              title: const Text('Email'),
              subtitle: Text(email),
            ),
            ListTile(
              leading: const Icon(Icons.chat_bubble, color: Colors.pinkAccent),
              title: const Text('Chats Participated'),
              trailing: Text('$chatCount'),
            ),
            ListTile(
              leading: const Icon(Icons.message, color: Colors.pinkAccent),
              title: const Text('Total Messages'),
              trailing: Text('$messageCount'),
            ),
          ],
        ),
      ),
    );
  }
}
