import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'profile_screen.dart';
import 'widgets/avatar_picker.dart';

class SettingsScreen extends StatefulWidget {
  final String userId;
  const SettingsScreen({super.key, required this.userId});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isDark = false;
  bool _loadingTheme = true;
  bool _isSleepy = false;
  bool _sleepyAutoReply = false;

  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _loadThemePref();
    _loadSleepyPrefs();
  }

  Future<void> _loadThemePref() async {
    final data = await supabase
        .from('users')
        .select('prefersDarkMode')
        .eq('id', widget.userId)
        .maybeSingle();

    if (!mounted || data == null) return;

    setState(() {
      _isDark = data['prefersDarkMode'] ?? false;
      _loadingTheme = false;
    });
  }

  Future<void> _loadSleepyPrefs() async {
    final data = await supabase
        .from('users')
        .select('isSleepyModeOn, sleepyAutoReply')
        .eq('id', widget.userId)
        .maybeSingle();

    if (!mounted || data == null) return;

    setState(() {
      _isSleepy = data['isSleepyModeOn'] ?? false;
      _sleepyAutoReply = data['sleepyAutoReply'] ?? false;
    });
  }

  Future<void> _updateThemePref(bool value) async {
    setState(() => _isDark = value);
    await supabase
        .from('users')
        .update({'prefersDarkMode': value}).eq('id', widget.userId);
  }

  Future<void> _updateSleepyMode(bool value) async {
    setState(() => _isSleepy = value);
    await supabase
        .from('users')
        .update({'isSleepyModeOn': value}).eq('id', widget.userId);
  }

  Future<void> _updateSleepyAutoReply(bool value) async {
    setState(() => _sleepyAutoReply = value);
    await supabase
        .from('users')
        .update({'sleepyAutoReply': value}).eq('id', widget.userId);
  }

  void _openProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProfileScreen(
          userId: widget.userId,
          username: widget.userId,
          avatarUrl: null,
        ),
      ),
    );
  }

  void _pickAndUploadChatBackground() {
    // 🟡 Placeholder: Will wire this once you send `background_picker.dart`
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: _loadingTheme
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                children: [
                  Center(child: AvatarPicker(userId: widget.userId)),
                  const SizedBox(height: 24),
                  ListTile(
                    leading: const Icon(Icons.person, color: Colors.pinkAccent),
                    title: const Text('Username'),
                    subtitle: const Text('Your lovely name here'),
                    trailing: const Icon(Icons.arrow_forward_ios,
                        color: Colors.pinkAccent, size: 16),
                    onTap: _openProfile,
                  ),
                  SwitchListTile(
                    secondary:
                        const Icon(Icons.dark_mode, color: Colors.pinkAccent),
                    title: const Text('Dark Mode'),
                    subtitle: const Text('Enable darker theme'),
                    value: _isDark,
                    onChanged: _updateThemePref,
                  ),
                  ListTile(
                    leading: const Icon(Icons.chat, color: Colors.pinkAccent),
                    title: const Text('Chat Background'),
                    subtitle: const Text('Pick a global chat background image'),
                    trailing: const Icon(Icons.arrow_forward_ios,
                        color: Colors.pinkAccent, size: 16),
                    onTap: _pickAndUploadChatBackground,
                  ),
                  const Divider(),
                  SwitchListTile(
                    secondary:
                        const Icon(Icons.bedtime, color: Colors.pinkAccent),
                    title: const Text('Sleepy Mode 😴'),
                    subtitle:
                        const Text('Do Not Disturb, but with fluffy vibes'),
                    value: _isSleepy,
                    onChanged: _updateSleepyMode,
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.auto_awesome,
                        color: Colors.pinkAccent),
                    title: const Text('Auto-reply while sleeping 💌'),
                    subtitle:
                        const Text('Send a sleepy message back automatically'),
                    value: _sleepyAutoReply,
                    onChanged: _isSleepy ? _updateSleepyAutoReply : null,
                  ),
                ],
              ),
      ),
    );
  }
}
