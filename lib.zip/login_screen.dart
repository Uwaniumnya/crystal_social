import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LoginScreen extends StatefulWidget {
  final Function(String username) onLogin;
  const LoginScreen({required this.onLogin, super.key});

  @override
  LoginScreenState createState() => LoginScreenState();
}

class LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  String? _error;
  bool _loading = false;

  Future<void> _login() async {
    final username = _usernameController.text.trim();
    final password = _passwordController.text.trim();
    final email = '$username@crystal.app';

    if (username.isEmpty || password.isEmpty) {
      setState(() => _error = "Please enter both username and password!");
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    final supabase = Supabase.instance.client;

    try {
      // Try to sign in
      final signInRes = await supabase.auth
          .signInWithPassword(email: email, password: password);

      if (signInRes.user == null) {
        setState(() => _error = "Login failed. Please check credentials.");
        return;
      }

      widget.onLogin(username);
    } on AuthException catch (e) {
      if (e.message.contains('Invalid login credentials')) {
        setState(() => _error = "Invalid username or password.");
      } else if (e.message.contains('User not found')) {
        // Try to register new user
        try {
          final signUpRes = await supabase.auth.signUp(
            email: email,
            password: password,
          );

          final userId = signUpRes.user?.id;
          if (userId != null) {
            await supabase.from('users').insert({
              'id': userId,
              'username': username,
              'created_at': DateTime.now().toIso8601String(),
            });
            widget.onLogin(username);
          } else {
            setState(() => _error = "Signup failed. Try again.");
          }
        } catch (e) {
          setState(() => _error = "Signup error: ${e.toString()}");
        }
      } else {
        setState(() => _error = "Auth error: ${e.message}");
      }
    } catch (e) {
      setState(() => _error = "Unexpected error: ${e.toString()}");
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFED8E6),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Welcome to PinkChat!',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: Colors.pinkAccent,
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _usernameController,
                  decoration: InputDecoration(
                    labelText: 'Username',
                    errorText: _error,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pinkAccent,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: _loading ? null : _login,
                  child: _loading
                      ? const CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2)
                      : const Text('Start Chatting 💕'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
