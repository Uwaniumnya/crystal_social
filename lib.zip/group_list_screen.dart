import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'group_chat_screen.dart';

class GroupListScreen extends StatelessWidget {
  final String currentUserId;

  const GroupListScreen({super.key, required this.currentUserId});

  @override
  Widget build(BuildContext context) {
    final supabase = Supabase.instance.client;

    return Scaffold(
      appBar: AppBar(title: const Text('Group Chats')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: supabase.from('chats').select().eq('isGroup', true).contains(
            'members', [currentUserId]).order('createdAt', ascending: false),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final groups = snapshot.data!;
          if (groups.isEmpty) {
            return const Center(child: Text('No groups yet 💔'));
          }

          return ListView.builder(
            itemCount: groups.length,
            itemBuilder: (context, index) {
              final group = groups[index];
              final name = group['name'] ?? 'Unnamed Group';
              final memberCount = (group['members'] as List).length;
              final chatId = group['id'];

              return ListTile(
                title: Text(name),
                subtitle: Text('Members: $memberCount'),
                leading: const CircleAvatar(child: Icon(Icons.group)),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => GroupChatScreen(
                        currentUserId: currentUserId,
                        chatId: chatId,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
