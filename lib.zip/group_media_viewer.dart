import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class GroupMediaViewer extends StatelessWidget {
  final String chatId;

  const GroupMediaViewer({super.key, required this.chatId});

  @override
  Widget build(BuildContext context) {
    final supabase = Supabase.instance.client;

    return Scaffold(
      appBar: AppBar(title: const Text('Shared Media')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: supabase
            .from('messages')
            .select('imageUrl')
            .eq('chat_id', chatId)
            .neq('imageUrl', '')
            .order('timestamp', ascending: false)
            .limit(100),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final images = snapshot.data!;
          if (images.isEmpty) {
            return const Center(child: Text('No images yet 🫠'));
          }

          return GridView.builder(
            padding: const EdgeInsets.all(8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: images.length,
            itemBuilder: (context, index) {
              final url = images[index]['imageUrl'];
              return ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(url, fit: BoxFit.cover),
              );
            },
          );
        },
      ),
    );
  }
}
