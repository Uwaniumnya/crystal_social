import 'dart:io';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';

import 'widgets/message_bubble.dart';
import 'group_settings_screen.dart';

class GroupChatScreen extends StatefulWidget {
  final String currentUserId;
  final String chatId;

  const GroupChatScreen({
    super.key,
    required this.currentUserId,
    required this.chatId,
  });

  @override
  State<GroupChatScreen> createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final supabase = Supabase.instance.client;

  String groupName = 'Group Chat';
  bool loadingGroupInfo = true;

  Map<String, String> memberNames = {};
  Map<String, String> memberAvatars = {};
  Map<String, String> personalNicknames = {};

  String? _replyToMessageId;
  String? _replyToText;
  String? _replyToSenderName;

  String? _reactingToMessageId;
  Offset? _pickerPosition;

  List<Map<String, dynamic>> messages = [];

  late RealtimeChannel _realtimeChannel;

  @override
  void initState() {
    super.initState();
    _loadGroupData();
    _loadPersonalNicknames();
    _subscribeToMessages();
  }

  @override
  void dispose() {
    _realtimeChannel.unsubscribe();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadGroupData() async {
    final chat = await supabase
        .from('chats')
        .select('name, members')
        .eq('id', widget.chatId)
        .single();

    groupName = chat['name'] ?? groupName;

    for (final uid in List<String>.from(chat['members'])) {
      final user = await supabase
          .from('users')
          .select('username, avatarUrl')
          .eq('id', uid)
          .maybeSingle();
      if (user != null) {
        memberNames[uid] = user['username'] ?? 'Unknown';
        memberAvatars[uid] = user['avatarUrl'] ?? '';
      }
    }

    setState(() => loadingGroupInfo = false);
  }

  Future<void> _loadPersonalNicknames() async {
    final nick = await supabase
        .from('group_nicknames')
        .select('nicknames')
        .eq('chat_id', widget.chatId)
        .eq('user_id', widget.currentUserId)
        .maybeSingle();

    if (nick != null) {
      personalNicknames = Map<String, String>.from(nick['nicknames'] ?? {});
    }
  }

  void _subscribeToMessages() {
    _realtimeChannel = supabase.channel('public:messages').on(
      RealtimeListenTypes.postgresChanges,
      ChannelFilter(event: 'INSERT', table: 'messages'),
      (payload, [ref]) {
        if (payload['new']['chat_id'] == widget.chatId) {
          setState(() {
            messages.insert(0, payload['new']);
          });
        }
      },
    ).subscribe();

    _loadInitialMessages();
  }

  Future<void> _loadInitialMessages() async {
    final res = await supabase
        .from('messages')
        .select()
        .eq('chat_id', widget.chatId)
        .order('timestamp', ascending: false)
        .limit(100);

    setState(() {
      messages = res;
    });
  }

  Future<void> _sendMessage({String? imageUrl}) async {
    final text = _controller.text.trim();
    if (text.isEmpty && imageUrl == null) return;

    final mentions = RegExp(r'@(\w+)')
        .allMatches(text)
        .map((m) => m.group(1))
        .whereType<String>()
        .toList();

    await supabase.from('messages').insert({
      'chat_id': widget.chatId,
      'sender_id': widget.currentUserId,
      'text': text.isEmpty ? null : text,
      'imageUrl': imageUrl,
      'timestamp': DateTime.now().toIso8601String(),
      'effect': null,
      'isSecret': false,
      'reactions': {},
      'mentions': mentions,
      'replyTo': _replyToMessageId,
    });

    _controller.clear();
    setState(() {
      _replyToMessageId = null;
      _replyToText = null;
      _replyToSenderName = null;
    });

    _scroll.animateTo(0,
        duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  Future<void> _pickAndSendImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    final file = File(picked.path);
    final bytes = await file.readAsBytes();
    final filename =
        '${widget.chatId}_${DateTime.now().millisecondsSinceEpoch}.jpg';

    await supabase.storage.from('chat_images').uploadBinary(filename, bytes);

    final url = supabase.storage.from('chat_images').getPublicUrl(filename);
    _sendMessage(imageUrl: url);
  }

  Future<String?> _getReplyPreview(String? replyToId) async {
    if (replyToId == null) return null;
    final reply = await supabase
        .from('messages')
        .select('text, imageUrl')
        .eq('id', replyToId)
        .maybeSingle();

    return reply?['text'] ?? (reply?['imageUrl'] != null ? '📷 Image' : null);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(groupName),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => GroupSettingsScreen(
                    currentUserId: widget.currentUserId,
                    chatId: widget.chatId,
                  ),
                ),
              );
            },
          )
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              Expanded(
                child: loadingGroupInfo
                    ? const Center(child: CircularProgressIndicator())
                    : ListView.builder(
                        reverse: true,
                        controller: _scroll,
                        itemCount: messages.length,
                        itemBuilder: (context, index) {
                          final msg = messages[index];
                          final isMe = msg['sender_id'] == widget.currentUserId;
                          final text = msg['text'];
                          final imageUrl = msg['imageUrl'];
                          final senderId = msg['sender_id'];
                          final displayName = personalNicknames[senderId] ??
                              memberNames[senderId] ??
                              'Unknown';
                          final timestamp =
                              DateTime.tryParse(msg['timestamp'] ?? '');
                          final effect = msg['effect'];
                          final isSecret = msg['isSecret'] ?? false;
                          final replyTo = msg['replyTo'];
                          final reactions = Map<String, List<String>>.from(
                              msg['reactions'] ?? {});
                          final hasMention = text?.contains(
                                  '@${memberNames[widget.currentUserId]}') ??
                              false;

                          return FutureBuilder<String?>(
                            future: _getReplyPreview(replyTo),
                            builder: (context, snap) {
                              return MessageBubble(
                                text: text,
                                imageUrl: imageUrl,
                                isMe: isMe,
                                timestamp: timestamp,
                                status: null,
                                avatarUrl:
                                    isMe ? null : memberAvatars[senderId],
                                effect: hasMention ? 'pulse' : effect,
                                isSecret: isSecret,
                                reactions: reactions,
                                username: !isMe ? displayName : null,
                                onReactTap: (emoji) async {
                                  final newReactions =
                                      Map<String, List<String>>.from(reactions);
                                  newReactions.update(
                                    emoji,
                                    (list) => list
                                            .contains(widget.currentUserId)
                                        ? (list..remove(widget.currentUserId))
                                        : (list..add(widget.currentUserId)),
                                    ifAbsent: () => [widget.currentUserId],
                                  );

                                  await supabase
                                      .from('messages')
                                      .update({'reactions': newReactions}).eq(
                                          'id', msg['id']);
                                },
                                onLongPress: () {
                                  RenderBox box =
                                      context.findRenderObject() as RenderBox;
                                  final position =
                                      box.localToGlobal(Offset.zero);
                                  setState(() {
                                    _reactingToMessageId = msg['id'];
                                    _pickerPosition = position;
                                  });
                                },
                                onTap: () {
                                  setState(() {
                                    _replyToMessageId = msg['id'];
                                    _replyToText = msg['text'] ?? '📷 Image';
                                    _replyToSenderName = displayName;
                                  });
                                },
                              );
                            },
                          );
                        },
                      ),
              ),
              if (_replyToMessageId != null)
                Container(
                  margin: const EdgeInsets.all(8),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.pink.shade50,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          '↪ ${_replyToSenderName ?? 'Someone'}: "${_replyToText ?? ''}"',
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          setState(() {
                            _replyToMessageId = null;
                            _replyToText = null;
                            _replyToSenderName = null;
                          });
                        },
                      )
                    ],
                  ),
                ),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.photo),
                      onPressed: _pickAndSendImage,
                    ),
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        decoration: const InputDecoration(
                          hintText: 'Type a message...',
                          border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(20))),
                        ),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.send),
                      onPressed: () => _sendMessage(),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (_reactingToMessageId != null && _pickerPosition != null)
            Positioned(
              bottom: 60,
              left: 20,
              right: 20,
              child: EmojiPicker(
                onEmojiSelected: (category, emoji) async {
                  final currentMsg = messages
                      .firstWhere((m) => m['id'] == _reactingToMessageId);
                  final current = Map<String, List<String>>.from(
                      currentMsg['reactions'] ?? {});
                  current.update(
                    emoji.emoji,
                    (list) => list.contains(widget.currentUserId)
                        ? (list..remove(widget.currentUserId))
                        : (list..add(widget.currentUserId)),
                    ifAbsent: () => [widget.currentUserId],
                  );

                  await supabase.from('messages').update(
                      {'reactions': current}).eq('id', _reactingToMessageId);

                  setState(() => _reactingToMessageId = null);
                },
              ),
            ),
        ],
      ),
    );
  }
}
