import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:supabase_flutter/supabase_flutter.dart';

class EditProfileScreen extends StatefulWidget {
  final String userId;
  final String currentUsername;
  final String? currentBio;
  final String? currentAvatarUrl;

  const EditProfileScreen({
    super.key,
    required this.userId,
    required this.currentUsername,
    this.currentBio,
    this.currentAvatarUrl,
  });

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController _usernameController;
  late TextEditingController _bioController;
  File? _newAvatarFile;
  String? _avatarPreviewUrl;
  bool _isSaving = false;

  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _usernameController = TextEditingController(text: widget.currentUsername);
    _bioController = TextEditingController(text: widget.currentBio ?? '');
    _avatarPreviewUrl = widget.currentAvatarUrl;
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  Future<void> _pickAvatarImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    setState(() {
      _newAvatarFile = File(picked.path);
      _avatarPreviewUrl = null;
    });
  }

  Future<String?> _uploadAvatar(File file) async {
    final fileName = path.basename(file.path);
    final filePath = '${widget.userId}/$fileName';

    await supabase.storage.from('user_avatars').uploadBinary(
          filePath,
          await file.readAsBytes(),
          fileOptions: const FileOptions(upsert: true),
        );

    return supabase.storage.from('user_avatars').getPublicUrl(filePath);
  }

  Future<void> _saveProfile() async {
    final newUsername = _usernameController.text.trim();
    final newBio = _bioController.text.trim();

    if (newUsername.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Username can't be empty! 🌸")),
        );
      }
      return;
    }

    setState(() {
      _isSaving = true;
    });

    String? avatarUrl = widget.currentAvatarUrl;

    if (_newAvatarFile != null) {
      try {
        avatarUrl = await _uploadAvatar(_newAvatarFile!);
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Avatar upload failed: $e")),
          );
        }
        setState(() {
          _isSaving = false;
        });
        return;
      }
    }

    try {
      await supabase.from('users').update({
        'username': newUsername,
        'bio': newBio,
        'avatarUrl': avatarUrl,
      }).eq('id', widget.userId);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile updated successfully! 💖')),
      );

      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update profile: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        backgroundColor: Colors.pinkAccent,
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _saveProfile,
            child: _isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                : const Text(
                    'Save',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold),
                  ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Center(
              child: Stack(
                alignment: Alignment.bottomRight,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: _avatarPreviewUrl != null
                        ? NetworkImage(_avatarPreviewUrl!)
                        : _newAvatarFile != null
                            ? FileImage(_newAvatarFile!)
                            : const AssetImage('assets/default_avatar.png')
                                as ImageProvider,
                  ),
                  FloatingActionButton(
                    mini: true,
                    backgroundColor: Colors.pinkAccent,
                    onPressed: _pickAvatarImage,
                    child: const Icon(Icons.camera_alt, size: 20),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(
                labelText: 'Username',
                prefixIcon: Icon(Icons.person, color: Colors.pinkAccent),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _bioController,
              maxLines: 4,
              decoration: const InputDecoration(
                labelText: 'Bio',
                prefixIcon: Icon(Icons.info_outline, color: Colors.pinkAccent),
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
