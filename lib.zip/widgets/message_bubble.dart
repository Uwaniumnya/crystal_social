import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class MessageBubble extends StatefulWidget {
  final String? text;
  final String? imageUrl;
  final bool isMe;
  final DateTime? timestamp;
  final String? status;
  final String? avatarUrl;
  final String? effect;
  final bool isSecret;
  final String? username;

  final Map<String, List<String>>? reactions;
  final VoidCallback? onLongPress;
  final Function(String emoji)? onReactTap;
  final VoidCallback? onTap;

  const MessageBubble({
    super.key,
    this.text,
    this.imageUrl,
    required this.isMe,
    this.timestamp,
    this.status,
    this.avatarUrl,
    this.reactions,
    this.onLongPress,
    this.onReactTap,
    this.effect,
    this.isSecret = false,
    this.username,
    this.onTap,
  });

  @override
  State<MessageBubble> createState() => _MessageBubbleState();
}

class _MessageBubbleState extends State<MessageBubble>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _pulse;
  late Animation<Offset> _float;
  bool _revealed = false;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    _pulse = Tween<double>(begin: 1.0, end: 1.1)
        .chain(CurveTween(curve: Curves.easeInOut))
        .animate(_controller);

    _float = Tween<Offset>(begin: Offset.zero, end: const Offset(0, -0.03))
        .chain(CurveTween(curve: Curves.easeInOut))
        .animate(_controller);

    if (widget.effect == 'pulse' || widget.effect == 'float') {
      _controller.repeat(reverse: true);
    }

    if (widget.effect == 'bounce') {
      _controller.forward().then((_) => _controller.reverse());
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String get formattedTime {
    if (widget.timestamp == null) return '';
    return DateFormat.jm().format(widget.timestamp!);
  }

  IconData getStatusIcon() {
    switch (widget.status) {
      case 'read':
        return Icons.done_all;
      case 'delivered':
        return Icons.done_all;
      case 'sent':
        return Icons.done;
      default:
        return Icons.access_time;
    }
  }

  Color getStatusColor() {
    switch (widget.status) {
      case 'read':
        return Colors.blueAccent;
      case 'delivered':
      case 'sent':
        return Colors.pink.shade300;
      default:
        return Colors.grey;
    }
  }

  Widget _wrapWithEffect(Widget child) {
    switch (widget.effect) {
      case 'pulse':
        return ScaleTransition(scale: _pulse, child: child);
      case 'float':
        return SlideTransition(position: _float, child: child);
      case 'bounce':
        return ScaleTransition(scale: _pulse, child: child);
      default:
        return child;
    }
  }

  @override
  Widget build(BuildContext context) {
    final bubbleColor =
        widget.isMe ? Colors.pink.shade200 : Colors.pink.shade50;
    final align =
        widget.isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start;

    final avatar = Container(
      padding: const EdgeInsets.all(4),
      decoration:
          const BoxDecoration(color: Color(0xFFFFDDEE), shape: BoxShape.circle),
      child: CircleAvatar(
        radius: 20,
        backgroundImage: widget.avatarUrl != null
            ? (widget.avatarUrl!.startsWith('http')
                ? NetworkImage(widget.avatarUrl!)
                : FileImage(File(widget.avatarUrl!)) as ImageProvider)
            : const AssetImage('assets/default_avatar.png'),
      ),
    );

    final messageContent = InkWell(
      onTap: () {
        if (widget.isSecret && !_revealed) {
          setState(() => _revealed = true);
        }
        widget.onTap?.call();
      },
      onLongPress: widget.onLongPress,
      borderRadius: BorderRadius.circular(20),
      splashColor: Colors.pink.withOpacity(0.2),
      highlightColor: Colors.pink.withOpacity(0.1),
      child: Container(
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
        padding: const EdgeInsets.all(12),
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        decoration: BoxDecoration(
          color: bubbleColor,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: widget.isMe ? const Radius.circular(20) : Radius.zero,
            bottomRight: widget.isMe ? Radius.zero : const Radius.circular(20),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.pinkAccent.withOpacity(0.2),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: widget.imageUrl != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.network(widget.imageUrl!, fit: BoxFit.cover),
              )
            : widget.isSecret && !_revealed
                ? Text(
                    "🔒 Tap to reveal",
                    style: TextStyle(
                      color: Colors.pink.shade800,
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w500,
                      fontSize: 16,
                    ),
                  )
                : Text(
                    widget.text ?? '',
                    style: TextStyle(
                      color: widget.isMe ? Colors.white : Colors.pink.shade800,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
      ),
    );

    final reactionRow = (widget.reactions != null &&
            widget.reactions!.isNotEmpty)
        ? Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 6,
              runSpacing: 4,
              children: widget.reactions!.entries.map((entry) {
                final emoji = entry.key;
                final count = entry.value.length;
                return GestureDetector(
                  onTap: () => widget.onReactTap?.call(emoji),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white70,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: const [
                        BoxShadow(
                            color: Colors.black12,
                            blurRadius: 2,
                            offset: Offset(0, 1)),
                      ],
                    ),
                    child: Text('$emoji $count',
                        style: const TextStyle(fontSize: 14)),
                  ),
                );
              }).toList(),
            ),
          )
        : const SizedBox.shrink();

    final timeAndStatus = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(formattedTime,
              style: TextStyle(fontSize: 12, color: Colors.pink.shade300)),
          if (widget.isMe && widget.status != null) ...[
            const SizedBox(width: 6),
            Icon(getStatusIcon(), size: 16, color: getStatusColor()),
          ],
        ],
      ),
    );

    final messageColumn = Column(
      crossAxisAlignment: align,
      children: [
        if (widget.username != null && !widget.isMe)
          Padding(
            padding: const EdgeInsets.only(left: 12, right: 12, bottom: 4),
            child: Text(
              widget.username!,
              style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[600]),
            ),
          ),
        if (widget.onTap != null && !widget.isMe)
          Padding(
            padding: const EdgeInsets.only(left: 16, bottom: 2),
            child: Row(
              children: [
                Icon(Icons.reply, size: 16, color: Colors.pink.shade200),
                const SizedBox(width: 4),
                Text('Tap to reply',
                    style:
                        TextStyle(fontSize: 12, color: Colors.pink.shade300)),
              ],
            ),
          ),
        _wrapWithEffect(messageContent),
        reactionRow,
        timeAndStatus,
      ],
    );

    return Row(
      mainAxisAlignment:
          widget.isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: widget.isMe
          ? [messageColumn, const SizedBox(width: 8), avatar]
          : [avatar, const SizedBox(width: 8), messageColumn],
    );
  }
}
