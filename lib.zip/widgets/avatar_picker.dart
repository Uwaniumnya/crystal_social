import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:supabase_flutter/supabase_flutter.dart';

class AvatarPicker extends StatefulWidget {
  final String userId;

  const AvatarPicker({super.key, required this.userId});

  @override
  AvatarPickerState createState() => AvatarPickerState();
}

class AvatarPickerState extends State<AvatarPicker> {
  File? _avatarImage;
  String? _avatarUrl;

  @override
  void initState() {
    super.initState();
    _loadAvatar();
  }

  Future<void> _loadAvatar() async {
    final res = await Supabase.instance.client
        .from('users')
        .select('avatar_url')
        .eq('id', widget.userId)
        .maybeSingle();

    if (!mounted) return;

    setState(() {
      _avatarUrl = res?['avatar_url'] as String?;
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    final file = File(picked.path);
    final fileName = path.basename(picked.path);
    final storagePath = '${widget.userId}/$fileName';

    final storageRes = await Supabase.instance.client.storage
        .from('avatars')
        .upload(storagePath, file,
            fileOptions: const FileOptions(upsert: true));

    if (!mounted) return;

    final url = Supabase.instance.client.storage
        .from('avatars')
        .getPublicUrl(storagePath);

    await Supabase.instance.client
        .from('users')
        .update({'avatar_url': url}).eq('id', widget.userId);

    if (!mounted) return;

    setState(() {
      _avatarImage = file;
      _avatarUrl = url;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text("Avatar updated! You're extra cute now 💅🫶")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: _pickImage,
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: const BoxDecoration(
              color: Color(0xFFFFDDEE),
              shape: BoxShape.circle,
            ),
            child: CircleAvatar(
              radius: 40,
              backgroundImage: _avatarImage != null
                  ? FileImage(_avatarImage!)
                  : (_avatarUrl != null
                          ? NetworkImage(_avatarUrl!)
                          : const AssetImage('assets/default_avatar.png'))
                      as ImageProvider,
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text("Tap the circle to choose your avatar 🥺👉👈")
      ],
    );
  }
}
