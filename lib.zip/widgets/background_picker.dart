import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatBackgroundPicker extends StatefulWidget {
  final String chatId;

  const ChatBackgroundPicker({super.key, required this.chatId});

  @override
  State<ChatBackgroundPicker> createState() => ChatBackgroundPickerState();
}

class ChatBackgroundPickerState extends State<ChatBackgroundPicker> {
  String? _backgroundUrl;
  File? _backgroundFile;

  @override
  void initState() {
    super.initState();
    _loadBackground();
  }

  Future<void> _loadBackground() async {
    final res = await Supabase.instance.client
        .from('chats')
        .select('background_url')
        .eq('chat_id', widget.chatId)
        .maybeSingle();

    if (res != null && mounted) {
      setState(() => _backgroundUrl = res['background_url'] as String?);
    }
  }

  Future<void> _pickAndUploadBackground() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    final file = File(picked.path);
    final fileName = path.basename(picked.path);
    final storagePath = '${widget.chatId}/$fileName';

    final storageRes = await Supabase.instance.client.storage
        .from('chat_backgrounds')
        .upload(storagePath, file,
            fileOptions: const FileOptions(upsert: true));

    if (storageRes.isNotEmpty) {
      final url = Supabase.instance.client.storage
          .from('chat_backgrounds')
          .getPublicUrl(storagePath);

      await Supabase.instance.client
          .from('chats')
          .update({'background_url': url}).eq('chat_id', widget.chatId);

      setState(() {
        _backgroundFile = file;
        _backgroundUrl = url;
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text("Chat background updated! Sooo pretty 💖✨")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GestureDetector(
          onTap: _pickAndUploadBackground,
          child: Container(
            height: 150,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.pink.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.pinkAccent),
              image: _backgroundFile != null
                  ? DecorationImage(
                      image: FileImage(_backgroundFile!), fit: BoxFit.cover)
                  : (_backgroundUrl != null
                      ? DecorationImage(
                          image: NetworkImage(_backgroundUrl!),
                          fit: BoxFit.cover)
                      : null),
            ),
            child: _backgroundUrl == null && _backgroundFile == null
                ? const Center(
                    child: Text(
                      "Tap to choose chat background 🥺👉👈",
                      style: TextStyle(color: Colors.pinkAccent),
                    ),
                  )
                : null,
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }
}
