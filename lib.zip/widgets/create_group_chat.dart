import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CreateGroupScreen extends StatefulWidget {
  final String currentUserId;
  final List<User> allUsers;

  const CreateGroupScreen({
    super.key,
    required this.currentUserId,
    required this.allUsers,
  });

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final TextEditingController _groupNameController = TextEditingController();
  final Set<String> _selectedUserIds = {};

  @override
  void initState() {
    super.initState();
    _selectedUserIds.add(widget.currentUserId); // auto-include self
  }

  Future<void> _createGroup() async {
    final groupName = _groupNameController.text.trim();
    if (groupName.isEmpty || _selectedUserIds.length < 2) return;

    final groupId = const Uuid().v4();

    final response = await Supabase.instance.client.from('chats').insert({
      'chat_id': groupId,
      'name': groupName,
      'is_group': true,
      'members': _selectedUserIds.toList(),
      'created_at': DateTime.now().toIso8601String(),
      'owner_id': widget.currentUserId,
      'admins': [widget.currentUserId],
      'emoji': '💬',
    });

    if (response.error == null && mounted) {
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                'Failed to create group: ${response.error?.message ?? 'Unknown error'}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Group Chat')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _groupNameController,
              decoration: const InputDecoration(labelText: 'Group Name'),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: widget.allUsers.map((user) {
                  return CheckboxListTile(
                    title: Text(user.name),
                    value: _selectedUserIds.contains(user.id),
                    onChanged: (val) {
                      setState(() {
                        if (val == true) {
                          _selectedUserIds.add(user.id);
                        } else {
                          _selectedUserIds.remove(user.id);
                        }
                      });
                    },
                  );
                }).toList(),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pinkAccent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _createGroup,
              child: const Text('Create Group 💕'),
            ),
          ],
        ),
      ),
    );
  }
}

// Local User model (not Supabase AuthUser)
class User {
  final String id;
  final String name;

  User({required this.id, required this.name});
}
