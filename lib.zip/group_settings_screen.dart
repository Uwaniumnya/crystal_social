import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'group_media_viewer.dart';

class GroupSettingsScreen extends StatefulWidget {
  final String currentUserId;
  final String chatId;

  const GroupSettingsScreen({
    super.key,
    required this.currentUserId,
    required this.chatId,
  });

  @override
  State<GroupSettingsScreen> createState() => _GroupSettingsScreenState();
}

class _GroupSettingsScreenState extends State<GroupSettingsScreen> {
  late TextEditingController _nameController;
  late TextEditingController _descController;
  late TextEditingController _emojiController;
  Map<String, String> personalNicknames = {};

  String avatarUrl = '';
  String bannerUrl = '';
  String ownerId = '';
  bool isLoading = true;

  List<String> adminIds = [];
  List<String> memberIds = [];

  final supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _descController = TextEditingController();
    _emojiController = TextEditingController();
    _loadGroup();
    _loadPersonalNicknames();
  }

  Future<void> _loadGroup() async {
    final chat =
        await supabase.from('chats').select().eq('id', widget.chatId).single();

    _nameController.text = chat['name'] ?? '';
    _descController.text = chat['description'] ?? '';
    _emojiController.text = chat['emoji'] ?? '💬';
    avatarUrl = chat['avatarUrl'] ?? '';
    bannerUrl = chat['bannerUrl'] ?? '';
    ownerId = chat['ownerId'] ?? '';
    adminIds = List<String>.from(chat['admins'] ?? []);
    memberIds = List<String>.from(chat['members'] ?? []);

    setState(() => isLoading = false);
  }

  Future<void> _loadPersonalNicknames() async {
    final nickRes = await supabase
        .from('group_nicknames')
        .select('nicknames')
        .eq('chat_id', widget.chatId)
        .eq('user_id', widget.currentUserId)
        .maybeSingle();

    if (nickRes != null && nickRes['nicknames'] is Map) {
      personalNicknames = Map<String, String>.from(nickRes['nicknames']);
    }
  }

  Future<void> _saveField(String field, dynamic value) async {
    await supabase.from('chats').update({field: value}).eq('id', widget.chatId);
  }

  Future<void> _uploadImage(String field, ImageSource source) async {
    final picked = await ImagePicker().pickImage(source: source);
    if (picked == null) return;

    final bytes = await File(picked.path).readAsBytes();
    final filename =
        '${widget.chatId}_${DateTime.now().millisecondsSinceEpoch}.jpg';
    final bucket = field == 'avatar' ? 'group_avatars' : 'group_banners';

    await supabase.storage.from(bucket).uploadBinary(filename, bytes);
    final url = supabase.storage.from(bucket).getPublicUrl(filename);

    await _saveField('${field}Url', url);
    setState(() {
      if (field == 'avatar') avatarUrl = url;
      if (field == 'banner') bannerUrl = url;
    });
  }

  void _editNickname(String uid, String fallback, String? current) {
    final controller = TextEditingController(text: current ?? fallback);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Set Nickname'),
        content: TextField(controller: controller),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final updated = controller.text.trim();
              personalNicknames[uid] = updated;
              await supabase.from('group_nicknames').upsert({
                'chat_id': widget.chatId,
                'user_id': widget.currentUserId,
                'nicknames': personalNicknames,
              }).onConflict(['chat_id', 'user_id']);
              setState(() {});
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleAdmin(String uid, {required bool promote}) async {
    final updated = promote
        ? {...adminIds, uid}
        : adminIds.where((id) => id != uid).toSet();

    await _saveField('admins', updated.toList());
    await _loadGroup();
  }

  Future<void> _transferOwnership(String uid) async {
    final updatedAdmins = {...adminIds, uid}.toList();
    await supabase.from('chats').update({
      'ownerId': uid,
      'admins': updatedAdmins,
    }).eq('id', widget.chatId);
    await _loadGroup();
  }

  Future<void> _removeMember(String uid) async {
    final updated = memberIds.where((id) => id != uid).toList();
    await _saveField('members', updated);
    await _loadGroup();
  }

  Future<void> _showAddMembersDialog() async {
    final users = await supabase.from('users').select('id, username');
    final existing = memberIds.toSet();
    final selected = <String>{};

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Add Members'),
        content: SizedBox(
          height: 400,
          width: double.maxFinite,
          child: ListView(
            children: users
                .where((u) => !existing.contains(u['id']))
                .map((user) => CheckboxListTile(
                      value: selected.contains(user['id']),
                      onChanged: (val) {
                        setState(() {
                          if (val == true) {
                            selected.add(user['id']);
                          } else {
                            selected.remove(user['id']);
                          }
                        });
                      },
                      title: Text(user['username'] ?? 'Unknown'),
                    ))
                .toList(),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final newMembers = [...existing, ...selected];
              await _saveField('members', newMembers);
              Navigator.pop(context);
              await _loadGroup();
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final isOwner = widget.currentUserId == ownerId;
    final isAdmin = isOwner || adminIds.contains(widget.currentUserId);

    return Scaffold(
      appBar: AppBar(title: const Text('Group Settings')),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children: [
                Container(
                  height: 160,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    image: bannerUrl.isNotEmpty
                        ? DecorationImage(
                            image: NetworkImage(bannerUrl), fit: BoxFit.cover)
                        : null,
                    color: Colors.pink.shade100,
                  ),
                  child: bannerUrl.isEmpty
                      ? const Center(child: Text('No Banner'))
                      : null,
                ),
                if (isAdmin)
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: ElevatedButton(
                      onPressed: () =>
                          _uploadImage('banner', ImageSource.gallery),
                      child: const Text('Change Banner'),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Stack(
                    children: [
                      CircleAvatar(
                        radius: 32,
                        backgroundImage: avatarUrl.isNotEmpty
                            ? NetworkImage(avatarUrl)
                            : const AssetImage('assets/default_avatar.png')
                                as ImageProvider,
                      ),
                      if (isAdmin)
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: InkWell(
                            onTap: () =>
                                _uploadImage('avatar', ImageSource.gallery),
                            child: Container(
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white,
                              ),
                              padding: const EdgeInsets.all(4),
                              child: const Icon(Icons.edit, size: 16),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _emojiController,
                            enabled: isAdmin,
                            decoration:
                                const InputDecoration(labelText: 'Emoji'),
                            onSubmitted: (val) =>
                                _saveField('emoji', val.trim()),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          _emojiController.text,
                          style: const TextStyle(fontSize: 32),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _nameController,
                enabled: isAdmin,
                decoration: const InputDecoration(labelText: 'Group Name'),
                onSubmitted: (val) => _saveField('name', val.trim()),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: TextField(
                controller: _descController,
                enabled: isAdmin,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Group Description',
                  hintText: 'Write a cute lil vibe message 💖',
                ),
                onSubmitted: (val) => _saveField('description', val.trim()),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Members',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  if (isAdmin)
                    IconButton(
                      icon: const Icon(Icons.person_add),
                      onPressed: _showAddMembersDialog,
                    ),
                ],
              ),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: memberIds.length,
              itemBuilder: (context, index) {
                final uid = memberIds[index];
                return FutureBuilder(
                  future: supabase
                      .from('users')
                      .select('username, avatarUrl')
                      .eq('id', uid)
                      .maybeSingle(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) return const SizedBox();
                    final user = snapshot.data as Map<String, dynamic>?;
                    final name = user?['username'] ?? 'Unknown';
                    final avatarUrl = user?['avatarUrl'];
                    final nickname = personalNicknames[uid];

                    return ListTile(
                      leading: CircleAvatar(
                        backgroundImage: avatarUrl != null
                            ? NetworkImage(avatarUrl)
                            : const AssetImage('assets/default_avatar.png')
                                as ImageProvider,
                      ),
                      title: Text(nickname ?? name),
                      subtitle: Row(
                        children: [
                          if (uid == ownerId) const Text('👑 Owner'),
                          if (uid != ownerId && adminIds.contains(uid))
                            const Text('🛡 Admin'),
                        ],
                      ),
                      trailing: (isOwner && uid != widget.currentUserId)
                          ? PopupMenuButton<String>(
                              onSelected: (value) {
                                if (value == 'remove') _removeMember(uid);
                                if (value == 'nickname')
                                  _editNickname(uid, name, nickname);
                                if (value == 'makeAdmin')
                                  _toggleAdmin(uid, promote: true);
                                if (value == 'removeAdmin')
                                  _toggleAdmin(uid, promote: false);
                                if (value == 'transferOwner')
                                  _transferOwnership(uid);
                              },
                              itemBuilder: (_) => [
                                const PopupMenuItem(
                                    value: 'nickname',
                                    child: Text('Set Nickname')),
                                const PopupMenuItem(
                                    value: 'remove', child: Text('Remove')),
                                if (!adminIds.contains(uid))
                                  const PopupMenuItem(
                                      value: 'makeAdmin',
                                      child: Text('Promote to Admin')),
                                if (adminIds.contains(uid) && uid != ownerId)
                                  const PopupMenuItem(
                                      value: 'removeAdmin',
                                      child: Text('Demote from Admin')),
                                const PopupMenuItem(
                                    value: 'transferOwner',
                                    child: Text('Transfer Ownership')),
                              ],
                            )
                          : null,
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
